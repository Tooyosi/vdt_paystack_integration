const models = require('../../connection/sequelize')
const { logger } = require('../../loggers/logger')
const request = require('request')
const { initializePayment, verifyPayment } = require('../../config/paystack')(request);


module.exports = {
    get: ('/', async (req, res) => {
        return res.render("landing/index");
    }),

    post: ('/', async (req, res) => {
        let { firstname, lastname, amount, email } = req.body
        const form = {
            fullName: firstname + " " + lastname,
            amount: Number(amount),
            email: email
        }
        form.metadata = {
            full_name: form.fullName
        }
        form.amount *= 100;
        initializePayment(form, (error, body)=>{
            if(error || !body){
                return logger.error(error)
            }else{
                console.log(body, "here")
                response = JSON.parse(body);
                if(response.status){
                    return res.redirect(response.data.authorization_url)
                }else {
                    logger.error(response.message)
                }
            }
        })
    }),

    paystack: ('/', async(req, res)=>{
        const ref = req.query.reference;
        verifyPayment(ref, (error, body) => {
            if (error || !body) {
                //handle errors appropriately
                console.log(error)
                
                return res.redirect('/')
            }else{
                response = JSON.parse(body);
                console.log(response)
                console.log(body)
                return res.redirect('/')

            }
            
        })
    })
};
